<?php
 include("config.php");
  if($_SERVER["REQUEST_METHOD"]=="GET")
{
  $id=$_GET['salon_id'];

	$queri="select * from product where salon_id='$id'";                    
	$result=mysqli_query($conn,$queri) or die("Query Not Executed " . mysqli_error($conn));
    $response=array();

			while ($row=mysqli_fetch_array($result)) 
			{
			        array_push($response, array(
					"userid"=>$row['id'],
					"proname"=>$row['name'],
					"proprice"=>$row['price'],
					"prodesc"=>$row['discription']
					));

				}
			
				echo json_encode($response);
				}
			
		?>