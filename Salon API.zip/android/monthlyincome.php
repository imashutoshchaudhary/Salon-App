<?php
 include("config.php");
  if($_SERVER["REQUEST_METHOD"]=="GET")
{
  $id=$_GET['salon_id'];

 
 	date_default_timezone_set("Asia/kolkata");
 	$date=date("m");
 	
 	


	$queri="select id,name,services,service_date,SUM(price) AS price from add_bill_user where month(service_date)='$date' and salon_id='$id' group by service_date";                    
	$result=mysqli_query($conn,$queri) or die("Query Not Executed " . mysqli_error($conn));
	$response=array();
		$i=0;		
		
							
while($abhi=mysqli_fetch_array($result)){

	
	
	array_push($response, array(
			        	"userid"=>$abhi['id'],
					"Name"=>$abhi['name'],
					"Service"=>$abhi['services'],
					"Date"=>$abhi['service_date'],
					"Price"=>$abhi['price']
					
					));
	
	
	}
	
			
					
				echo json_encode($response);
				
				
				
	$query="select SUM(price) AS price from stock where month(insert_date)='$date' group by insert_date and salon_id='$id'";                    
	$results=mysqli_query($conn,$query) or die("Query Not Executed " . mysqli_error($conn));
	$responses=array();
		$i=0;		
		
							
while($abhis=mysqli_fetch_array($results)){

	
	
	array_push($responses, array(
			        	
					"Prices"=>$abhis['price']
					
					));
	
	
	}
	
			
					
				echo json_encode($responses);			
			}
		?>