<?php

if($_SERVER["REQUEST_METHOD"]=="GET")
{
	include "config.php";
       
       $getselectservice=$_GET['services'];
        $getselectsubservice=$_GET['sub_services'];
        $getprice=$_GET['price'];
         $id=$_GET['salon_id'];

	
	$query="insert INTO sub_services(services,sub_services,price,salon_id) values('$getselectservice','$getselectsubservice','$getprice','$id')";
	
	if(mysqli_query($conn,$query))
	{
	   echo "data inserted";
	   
	   		 }
			 
			 else
			 {
			   echo "data not inserted";
			 }
			 
		 }
		 
		 
		 
		 
		 
?>