<?php

if($_SERVER['REQUEST_METHOD']=="GET")

{

	$id=$_GET['id'];
	$title=$_GET['title'];

	
	include("config.php");
	
	$queri="delete from sms_template where id='$id' AND title='$title'";
	
	if(mysqli_query($conn,$queri))
	
{
	echo "data deleted";
}

else

{
	echo "data not deleted";
}

}

?>