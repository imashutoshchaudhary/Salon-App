<?php
 include("config.php");
	$queri="select * from users";                    
	$result=mysqli_query($conn,$queri) or die("Query Not Executed " . mysqli_error($conn));
    $response=array();

			while ($row=mysqli_fetch_array($result)) 
			{
			        array_push($response, array(
					"userid"=>$row['id'],
					"ename"=>$row['name'],
					"eemail"=>$row['email'],
					"eph"=>$row['phone']
					));

				}
			
				echo json_encode($response);
			
		?>