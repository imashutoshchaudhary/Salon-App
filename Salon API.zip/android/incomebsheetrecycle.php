<?php
 include("config.php");
	$queri="select * from add_bill_user";                    
	$result=mysqli_query($conn,$queri) or die("Query Not Executed " . mysqli_error($conn));
    $response=array();

			while ($row=mysqli_fetch_array($result)) 
			{
			        array_push($response, array(
					"userid"=>$row['id'],
					"name"=>$row['name'],
					"i_price"=>$row['price'],
					"i_date"=>$row['date_of_birth'],
					
					
					));

				}
			
				echo json_encode($response);
			
		?>