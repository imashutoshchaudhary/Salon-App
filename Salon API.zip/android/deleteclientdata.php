<?php

	
if($_SERVER['REQUEST_METHOD']=="GET")

{

	$email=$_GET['email'];
	
	include("config.php");
	
	$queri="delete from users where email='$email'";
	
	if(mysqli_query($conn,$queri))
	
{
	echo "data deleted";
}

else

{
	echo "data not deleted";
}

}

?>