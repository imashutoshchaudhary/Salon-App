<?php 

$user="root";
$host="localhost";
$pass="";
$database="api";

$conn=$mysqli_connect($host,$user,$pass,$database);

if(!$conn)
{
   echo "Connection Failed";
}
else
{
  echo "Connection successfully";
}


?>