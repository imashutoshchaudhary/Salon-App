<?php

if($_SERVER["REQUEST_METHOD"]=="GET")
{
	include "config.php";
	
        $name=$_GET['name'];
        $phone=$_GET['phone'];
        $dob=$_GET['date_of_birth'];
        $addrs=$_GET['address'];
        

	
	$query="insert INTO users(name,phone,date_of_birth,address) values('$name','$phone','$dob','$addrs')";
	
	if(mysqli_query($conn,$query))
	{
	   echo "data inserted";
	   
	   		 }
			 
			 else
			 {
			   echo "data not inserted";
			 }
			 
		 }
		 
		 
		 
		 
		 
?>