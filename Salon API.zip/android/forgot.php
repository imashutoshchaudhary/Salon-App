<?php
session_start();

if ($_SERVER['REQUEST_METHOD']=="GET") 
{
include"config.php";

        $useremail=$_GET['email'];
  	$pass=$_GET['password'];
  
        
$query="update admin set password='$pass' where email='$useremail'";

$f=mysqli_query($conn,$query);

if ($f)
 {
    echo "passsword changed successfully";
}
else
{
    echo "failed";
}
}
?>

