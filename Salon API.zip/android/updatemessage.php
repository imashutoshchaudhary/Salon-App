<?php
if($_SERVER['REQUEST_METHOD']=="GET")
{
	$sid=$_GET['salon_id'];
	
	$title=$_GET['title'];
	$content=$_GET['content'];
	
	
	include("config.php");
	
	
	//echo "id=".$sid."title=".$title."content=".$content;
	
	$queri="update sms_template set title='$title',content='$content'  where salon_id='$sid'";
	
	if(mysqli_query($conn,$queri))
{
	echo "data updated";
}
else
{
	echo "data not updated";
}
}
?>