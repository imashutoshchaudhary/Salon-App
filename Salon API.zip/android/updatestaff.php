<?php
if($_SERVER['REQUEST_METHOD']=="GET")
{
	$id=$_GET['salon_id'];
	$staffname=$_GET['name'];
	$staffemail=$_GET['email'];
	$staffphone=$_GET['phone'];
	$staffsalary=$_GET['salary'];
	$staffaddrs=$_GET['address'];
	include("config.php");
	
	//echo "id=".$id."name=".$staffname."email=".$staffemail."phone=".$staffphone."salary=".$staffsalary."address=".$staffaddrs;
	
	$queri="update staff set name='$staffname',phone='$staffphone',salary='$staffsalary',address='$staffaddrs' where salon_id='$id' AND email='$staffemail' ";
	
	if(mysqli_query($conn,$queri))
{
	echo "data updated";
}
else
{
	echo "data not updated";
}
}
?>