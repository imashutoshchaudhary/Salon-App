<?php

if($_SERVER["REQUEST_METHOD"]=="GET")
{
	include "config.php";
	
        $exp_name=$_GET['name'];
        $exp_amnt=$_GET['total_amount'];
        $exp_desc=$_GET['description'];
	$exp_date=$_GET['date_current'];
         $id=$_GET['salon_id'];
        	
	$query="insert INTO expances(name,total_amount,description,date_current,salon_id) values('$exp_name','$exp_amnt','$exp_desc','$exp_date','$id')";
	
	if(mysqli_query($conn,$query))
	{
	   echo "data inserted";
	   
	   		 }
			 
			 else
			 {
			   echo "data not inserted";
			 }
			 
		 }
		 
		 
		 
		 
		 
?>