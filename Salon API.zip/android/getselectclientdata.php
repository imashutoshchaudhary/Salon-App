<?php

include ("config.php");
 if($_SERVER["REQUEST_METHOD"]=="GET")
{
  $id=$_GET['salon_id'];

	
 
$getname=$_GET['name'];
$getphone=$_GET['phone'];
 
$query="SELECT date_of_birth,address FROM users where name='$getname', phone='$getphone'and salon_id='$id'";

 
$result = mysqli_query($conn, $query);

$fetchdta=mysqli_fetch_array($result);

$dobis=$fetchdta["date_of_birth"];
$addrsis=$fetchdta["address"];
 
echo $contentis;
 }
?>