<?php

if($_SERVER["REQUEST_METHOD"]=="GET")

{

   $getusername=$_GET['name'];
	$getphone=$_GET['phone'];
	$getdob=$_GET['date_of_birth'];
	$getselectservice=$_GET['services'];
	$getselectprice=$_GET['price'];
	 $id=$_GET['salon_id'];
	
	include "config.php";
	
	date_default_timezone_set("Asia/kolkata");
 	$date=date("y-m-d");
	$query="insert into add_bill_user(name,phone,date_of_birth,service_date,services,price,salon_id) values('$getusername','$getphone','$getdob','$date','$getselectservice','$getselectprice','$id')";
	
	if(mysqli_query($conn,$query))
	{
	   echo "data inserted";
	   
	   $query1="select * from add_bill_user" ;
      
	  $rltstock=mysqli_query($conn,$query1);
	  $repstock=array();
	  
	  if(mysqli_num_rows($rltstock)>0)
	  {
	      while($row=mysqli_fetch_array($result))
		  {
		  
		     if($row)
			 {
			    array_push($repstock,array(
			    "id"=>$row['id'],
				"name"=>$row['name'],
				"clientphone"=>$row['phone'],
				"dob"=>$row['date_of_birth'],
				"service"=>$row['services'],
				"price"=>$row['price']));
			 }
			 
			 else
			 {
			   echo "no data found";
			 }
			 
		 }
		  
		  echo json_encode($repstock);
	  }
	  
	}
	else
	{
	  echo "data not inserted";
	}
}
?>