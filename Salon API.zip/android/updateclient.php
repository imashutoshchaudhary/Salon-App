<?php
if($_SERVER['REQUEST_METHOD']=="GET")
{
include("config.php");

	$salon_id=$_GET['salon_id'];
	$name=$_GET['name'];
	$email=$_GET['email'];
	$phone=$_GET['phone'];
	//$userage=$_GET['age'];
	//$useraddrs=$_GET['address'];
	//$userdob=$_GET['date_of_birth'];
	
	
	
	
	//echo "id=".$sid."name=".$username."email=".$usermail."phone=".$userphone."age=".$userage."address=".$useraddrs."date_of_birth=".date_of_birth;
	
	// $queri="update users set name='$username',email='$usermail',phone='$userphone',age='$userage',address='$useraddrs',date_of_birth='$userdob' where salon_id='$sid'";
	
	$queri="update users set name='$name',phone='$phone' where salon_id='$salon_id' AND email='$email'";
	
	if(mysqli_query($conn,$queri))
{
	echo "data updated";
}

else
{
	echo "data not updated";
}

}
?>