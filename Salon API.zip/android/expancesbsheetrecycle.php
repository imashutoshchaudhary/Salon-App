<?php
 include("config.php");
	$queri="select * from expances";                    
	$result=mysqli_query($conn,$queri) or die("Query Not Executed " . mysqli_error($conn));
    $response=array();

			while ($row=mysqli_fetch_array($result)) 
			{
			        array_push($response, array(
					"userid"=>$row['id'],
					"name"=>$row['name'],
					"ex_amnt"=>$row['total_amount'],
					"date"=>$row['date_current'],
					
					
					));

				}
			
				echo json_encode($response);
			
		?>