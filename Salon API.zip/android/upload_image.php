<?php

if($_SERVER["REQUEST_METHOD"]=="GET")
{
	include "config.php";
	
	$img=$_GET['image'];
	$img=$_FILES["image"]["name"];
    	$target_dir = "uploads/";
$target_file = $target_dir . $_FILES["image"]["name"];
move_uploaded_file($_FILES["image"]["tmp_name"], $target_file);
	
	$query="insert INTO image(name) values('$img')";
	
	if(mysqli_query($conn,$query))
	{
	   echo "Image Uploaded";
	   
	}
			 
			 else
			 {
			   echo "image not Uploaded";
			 }
			 
}
		 
		 
		 
		 
		 
?>