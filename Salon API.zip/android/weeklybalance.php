<?php
 include("config.php");
 if($_SERVER["REQUEST_METHOD"]=="GET")
{
  $id=$_GET['salon_id'];

 	date_default_timezone_set("Asia/kolkata");
 	echo $date;
	$queri="select * from add_bill_user where service_date> DATE_SUB(NOW(), INTERVAL 1 WEEK) and salon_id='$id' ORDER BY service_date DESC";    
               
	$result=mysqli_query($conn,$queri) or die("Query Not Executed " . mysqli_error($conn));
	
		$i=0;									
while($abhi=mysqli_fetch_array($result)){
	$inc_total += $abhi['price'];
	$i++;

	}
	$query="select * from stock where insert_date> DATE_SUB(NOW(), INTERVAL 1 WEEK) ORDER BY insert_date DESC";                    
	$results=mysqli_query($conn,$query) or die("Query Not Executed " . mysqli_error($conn));
											
while($abhi1=mysqli_fetch_array($results)){

	$exp_total += $abhi1['price'];
	$i++;
	}
	$total=$inc_total-$exp_total;
					
									echo $total;
			}
		?>