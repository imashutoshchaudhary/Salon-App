<?php

if($_SERVER["REQUEST_METHOD"]=="GET")
{
	include "config.php";
	
        $name=$_GET['name'];
        $email=$_GET['email'];
        $phone=$_GET['phone'];
         $id=$_GET['id'];
        

	
//	$query="insert INTO users(name,email,phone,sex,date_of_birth,salon_id) values('$a','$b','$c','$e','$f', '$id')";

        $query="UPDATE  users SET name='$name', email='$email',phone='$phone' WHERE id='$id'";



	
	if(mysqli_query($conn,$query))
	{
	   echo "data inserted";
	   
	   		 }
			 
			 else
			 {
			   echo "data not inserted";
			 }
			 
		 }
		 
		 
		 
		 
		 
?>