<?php
if($_SERVER['REQUEST_METHOD']=="GET")
{
	$id=$_GET['salon_id'];
	$brname=$_GET['brandname'];
	$pname=$_GET['productname'];
	$quantity=$_GET['quantity'];
	$price=$_GET['price'];

	
	include("config.php");
	
	
	//echo "id=".$id."brandname=".$brname."productname=".$pname."quantity=".$quantity."$price=".price;
	
	$queri="update stock set brandname='$brname',productname='$pname',quantity='$quantity',price='$price' where salon_id='$id'";
	
	if(mysqli_query($conn,$queri))
	
{
	echo "data updated";
}
else
{
	echo "data not updated";
}

}
?>