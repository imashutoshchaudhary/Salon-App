<?php
session_start();

if ($_SERVER['REQUEST_METHOD']=="GET") 
{
include"config.php";

        $useremail=$_GET['email'];
  
        $userpassword=$_GET['password'];
        
$query="select * from admin WHERE email= '$useremail' and password= '$userpassword'";

// $f=mysqli_query($conn,$query);

$f=mysql_query($query) or die(mysqli_error());

// $count=mysqli_num_rows($f);

$count=mysql_num_rows($f);

$data=mysqli_fetch_array($f);

$id=$data['id'];

if ($count==1)
 {
      
    echo 1;
}
else
{
    echo "0";
}
}
?>

