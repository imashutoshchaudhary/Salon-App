<?php

if($_SERVER["REQUEST_METHOD"]=="GET")
{
	include "config.php";
	
        $getproductname=$_GET['name'];
        $getproductprice=$_GET['price'];
        $getproductdescription=$_GET['discription'];
         $id=$_GET['salon_id'];

	
	$query="INSERT INTO product(name,price,discription,salon_id) values('$getproductname','$getproductprice','$getproductdescription','$id')";
	
	if(mysqli_query($conn,$query))
	{
	   echo "data inserted";
	   
	   		 }
			 
			 else
			 {
			   echo "data not inserted";
			 }
			 
		 }
		 
		 
		 
		 
		 
?>