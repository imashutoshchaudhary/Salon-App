<?php

if($_SERVER["REQUEST_METHOD"]=="GET")
{
	include "config.php";
	
        $a=$_GET['name'];
        $b=$_GET['email'];
        $c=$_GET['phone'];
        $e=$_GET['sex'];
        $f=$_GET['date_of_birth'];
         $id=$_GET['salon_id'];
        

	
	$query="insert INTO users(name,email,phone,sex,date_of_birth,salon_id) values('$a','$b','$c','$e','$f', '$id')";
	
	if(mysqli_query($conn,$query))
	{
	   echo "data inserted";
	   
	   		 }
			 
			 else
			 {
			   echo "data not inserted";
			 }
			 
		 }
		 
		 
		 
		 
		 
?>