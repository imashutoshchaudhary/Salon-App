<?php
 include("config.php");
 if($_SERVER["REQUEST_METHOD"]=="GET")
{
  $id=$_GET['salon_id'];

	$queri="select * from sub_services where salon_id='$id'";           
	$result=mysqli_query($conn,$queri) or die("Query Not Executed " . mysqli_error($conn));
    $response=array();

			while ($row=mysqli_fetch_array($result)) 
			{
			        array_push($response, array(
					"userid"=>$row['id'],
					"servicename"=>$row['services'],
					"subservicename"=>$row['sub_services'],
					"subserviceprice"=>$row['price']
					));

				}
			
				echo json_encode($response);
				}
			
?>