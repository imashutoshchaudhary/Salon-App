<?php
 include("config.php");
 if($_SERVER["REQUEST_METHOD"]=="GET")
{
  $id=$_GET['salon_id'];

	$queri="select * from staff where salon_id='$id'";                     
	$result=mysqli_query($conn,$queri) or die("Query Not Executed " . mysqli_error($conn));
    $response=array();

			while ($row=mysqli_fetch_array($result)) 
			{
			        array_push($response, array(
					"userid"=>$row['id'],
					"stfname"=>$row['name'],
					"stfphone"=>$row['phone'],
					"stfemail"=>$row['email'],
					"stfsalary"=>$row['salary'],
					"stfaddrs"=>$row['address'],
					));

				}
			
				echo json_encode($response);
				
	}
			
		?>