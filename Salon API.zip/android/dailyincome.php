<?php
 include("config.php");
  if($_SERVER["REQUEST_METHOD"]=="GET")
{
	  $id=$_GET['salon_id'];
 	date_default_timezone_set("Asia/kolkata");
 	$date=date("y-m-d");
	$queri="select * from add_bill_user where service_date='$date' and salon_id='$id'";                    
	$result=mysqli_query($conn,$queri) or die("Query Not Executed " . mysqli_error($conn));
	$response=array();
		$i=0;									
while($abhi=mysqli_fetch_array($result)){
	
	
	array_push($response, array(
			        	"userid"=>$abhi['id'],
					"Name"=>$abhi['name'],
					"Service"=>$abhi['services'],
					"Date"=>$abhi['service_date'],
					"Price"=>$abhi['price']
				
					));
	
	
	}
	
			
					
				echo json_encode($response);
			}
		?>