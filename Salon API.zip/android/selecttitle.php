<?php

include ("config.php");
 if($_SERVER["REQUEST_METHOD"]=="GET")
{
  $id=$_GET['salon_id'];

 
$title=$_GET['title'];
 
$query="SELECT * FROM sms_template where title='$title' and salon_id='$id'";

 
$result = mysqli_query($conn, $query);

$fetchdta=mysqli_fetch_array($result);
$contentis=$fetchdta["content"];
 
echo $contentis;
 }
?>