<?php

if($_SERVER["REQUEST_METHOD"]=="GET")
{
	include "config.php";
        $getsmstitle=$_GET['title'];
        $getsmscontent=$_GET['content'];
         $id=$_GET['salon_id'];
	
	
	
	$query="insert INTO sms_template(title,content,salon_id) values('$getsmstitle','$getsmscontent','$id')";
	
	if(mysqli_query($conn,$query))
	{
	   echo "data inserted";
	   
	   		 }
			 
			 else
			 {
			   echo "data not inserted";
			 }
			 
		 }
		 
		 
		 
		 
		 
?>