<?php
 include("config.php");
  if($_SERVER["REQUEST_METHOD"]=="GET")
{
  $id=$_GET['salon_id'];

 
 	date_default_timezone_set("Asia/kolkata");
 	$date=date("m");
 	
 	

$query="select SUM(price) AS price from stock where month(insert_date)='$date' and salon_id='$id' group by insert_date";                    
	$results=mysqli_query($conn,$query) or die("Query Not Executed " . mysqli_error($conn));
	$responses=array();
		$i=0;		
		
							
while($abhis=mysqli_fetch_array($results)){

	
	
	array_push($responses, array(
			        	
					"Prices"=>$abhis['price']
					
					));
	
	
	}
	
			
					
				echo json_encode($responses);			
			}
		?>