<?php
if($_SERVER['REQUEST_METHOD']=="GET")
{
	$sid=$_GET['id'];
	$extname=$_GET['name'];
	$extphone=$_GET['phone'];
	$extdob=$_GET['date_of_birth'];
	$extaddrs=$_GET['address'];
	
	include("config.php");
	
	
	echo "id=".$sid."name=".$extname."phone=".$extphone."date_of_birth=".$extdob."address=".$extaddrs;
	
	$queri="update users set name='$extname',phone='$extphone',date_of_birth='$extdob',address='$useraddrs' where id='$sid'";
	
	if(mysqli_query($conn,$queri))
{
	echo "data updated";
}
else
{
	echo "data not updated";
}
}
?>