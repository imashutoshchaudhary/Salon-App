<?php
session_start();
if(isset($_SESSION['admin'])){
if($_SERVER["REQUEST_METHOD"]=="GET")
{
	include "config.php";
	
        $add_name=$_GET['name'];
       $add_dob=$_GET['date_of_birth'];
	$add_phone=$_GET['phone'];
        $add_desc=$_GET['description'];
        $add_total=$_GET['price'];
        $id=$_SESSION['admin'];
	echo $id;
	$query="insert INTO add_bill_user(name,date_of_birth,phone,description,price,salon_id) values('$add_name','$add_dob','$add_phone','$add_desc','$add_total','$id')";
	
	if(mysqli_query($conn,$query))
	{
	   echo "data inserted";
	   
	   		 }
			 
			 else
			 {
			   echo "data not inserted";
			 }
			 
		 }
		 
		 
	}
	 
		 
		 
?>