<?php
session_start();
include ('config.php');
if ($_SERVER['REQUEST_METHOD']=="GET") 
{


              $useremail=$_GET['email'];
  
        $userpassword=$_GET['password'];
        
$query="select * from admin WHERE email= '$useremail' and password= '$userpassword'";

$f=mysqli_query($conn,$query) or die(mysqli_error($conn));

$count=mysqli_num_rows($f);



if ($count==1)
 {
   
    echo "1";
}
else
{
    echo "0";
}
}
?>
