<?php

include ("config.php");
 
$ids_GET['id'];
 
$query="SELECT name FROM users where id='$ids'";

 
$result = mysqli_query($conn, $query);

$fetchdta=mysqli_fetch_array($result);
$nameis=$fetchdta["name"];
 
echo $nameis;
 
?>