<?php

if($_SERVER['REQUEST_METHOD']=="GET")

{

	$ids=$_GET['salon_id'];
	$email=$_GET['email'];
	
	include("config.php");
	
	$queri="delete from staff where salon_id='$ids' AND email='$email'";
	
	if(mysqli_query($conn,$queri))
	
{
	echo "data deleted";
}

else

{
	echo "data not deleted";
}

}

?>