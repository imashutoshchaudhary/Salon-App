<?php
 include("config.php");
 if($_SERVER["REQUEST_METHOD"]=="GET")
{
  $id=$_GET['salon_id'];

 
 	date_default_timezone_set("Asia/kolkata");
 	$date=date("m");
 	
 	

	$queris="SELECT * FROM add_bill_user WHERE service_date> DATE_SUB(NOW(), INTERVAL 1 WEEK) and salon_id='$id' ORDER BY service_date DESC";
	//$queri="select * from add_bill_user where month(service_date)='$date'";                    
	$results=mysqli_query($conn,$queris) or die("Query Not Executed " . mysqli_error($conn));
	$responses=array();
		$i=0;									
while($abhi=mysqli_fetch_array($results)){
	
	
	array_push($responses, array(
			        	"userid"=>$abhi['id'],
					"Name"=>$abhi['name'],
					"Service"=>$abhi['services'],
					"Date"=>$abhi['service_date'],
					"Price"=>$abhi['price']
				
					));
	
	}
	echo json_encode($responses);
			
					$queri="SELECT * FROM stock WHERE insert_date> DATE_SUB(NOW(), INTERVAL 1 WEEK) ORDER BY insert_date DESC";
	//$queri="select * from add_bill_user where month(service_date)='$date'";                    
	$result=mysqli_query($conn,$queri) or die("Query Not Executed " . mysqli_error($conn));
	$response=array();
		$i=0;								
		while($abhi=mysqli_fetch_array($result)){
	
	
	array_push($response, array(
			        	"Prices"=>$abhi['prices']
				
					));
	
	
	}
	
	
	
				echo json_encode($response);
				}
			
		?>