<?php

include ("config.php");
 
 
$s_service=$_GET['services'];
 
$query="SELECT sub_services,price FROM sub_services where services='$s_service'";

 
$result = mysqli_query($conn, $query);

$fetchdta=mysqli_fetch_array($result);

$ssis=$fetchdta["sub_services"];
$prcieis=$fetchdta["price"];

echo $ssis."#".$prcieis;
 
 
?>