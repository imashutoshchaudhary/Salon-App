<?php

if($_SERVER["REQUEST_METHOD"]=="GET")
{
	include "config.php";
        $getbrandname=$_GET['brandname'];
        $getproductname=$_GET['productname'];
	$getquantity=$_GET['quantity'];
	$getprice=$_GET['price'];
	$getdate=$_GET['date'];
	 $id=$_GET['salon_id'];
	//$getimage=$_GET['image'];

	date_default_timezone_set("Asia/kolkata");
 	$date=date("y-m-d");
	$query="insert INTO stock(brandname,productname,quantity,price,date,insert_date,salon_id) values('$getbrandname','$getproductname','$getquantity','$getprice','$getdate','$date','$id')";
	
	if(mysqli_query($conn,$query))
	{
	   echo "data inserted";
	   
	   		 }
			 
			 else
			 {
			   echo "data not inserted";
			 }
			 
		 }
		 
		 
		 
		 
		 
?>