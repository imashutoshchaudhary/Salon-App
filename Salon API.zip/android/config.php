<?php


$conn = mysqli_connect("localhost","brilligs_salon","brill@salon","brilligs_salon");

if(!$conn)
{
  echo "Connection Failed";
}


?>