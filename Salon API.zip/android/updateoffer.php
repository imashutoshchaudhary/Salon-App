<?php
if($_SERVER['REQUEST_METHOD']=="GET")
{
	$sid=$_GET['salon_id'];
	$name=$_GET['name'];
       $amount=$_GET['amount'];
	$coupon=$_GET['coupon_code'];
	
	include("config.php");
	
	
	//echo "id=".$sid."name=".$username."email=".$usermail."phone=".$userphone."age=".$userage."address=".$useraddrs."date_of_birth=".date_of_birth;
	
	$queri="update users set name='$name',amount='$amount',coupon_code='$coupon' where salon_id='$sid'";
	
	if(mysqli_query($conn,$queri))
{
	echo "data updated";
}

else
{
	echo "data not updated";
}

}
?>