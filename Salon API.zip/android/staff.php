<?php

if($_SERVER["REQUEST_METHOD"]=="GET")
{
	include "config.php";
       
       $getstaffname=$_GET['name'];
	   $getstaffemail=$_GET['email'];
	   $getstaffphone=$_GET['phone'];
	   $getstaffdob=$_GET['dob'];
	   $getstaffgen=$_GET['gender'];
	   $getstaffaddress=$_GET['address'];
	   $getstaffsallary=$_GET['salary'];
	    $id=$_GET['salon_id'];
        

	
	$query="insert INTO staff(name,email,phone,dob,gender,address,salary,salon_id) values('$getstaffname','$getstaffemail','$getstaffphone','$getstaffdob','$getstaffgen','$getstaffaddress','$getstaffsallary','$id')";
	
	if(mysqli_query($conn,$query))
	{
	   echo "data inserted";
	   
	   		 }
			 
			 else
			 {
			   echo "data not inserted";
			 }
			 
		 }
		 
		 
		 
		 
		 
?>