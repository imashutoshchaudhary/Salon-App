<?php
if($_SERVER['REQUEST_METHOD']=="GET")
{
	$sid=$_GET['salon_id'];
	
	$name=$_GET['name'];
	$productprice=$_GET['price'];
	$prodesct=$_GET['discription'];
	
	
	include("config.php");
	
	$queri="update users set name='$name',productprice='$price',prodesct='$discription' where salon_id='$sid'";
	

	//$queri="update product set name='$name',price='$productprice',discription='$prodesct' where id='$sid'";
	
	if(mysqli_query($conn,$queri))
{
	echo "data updated";
}
else
{
	echo "data not updated";
}

}
?>