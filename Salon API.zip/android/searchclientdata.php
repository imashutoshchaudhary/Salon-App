<?php

include ("config.php");
 
 
$getphone=$_GET['phone'];
 
$query="SELECT * FROM users where phone='$getphone'";

 
$result = mysqli_query($conn, $query);

$fetchdta=mysqli_fetch_array($result);

$idis=$fetchdta["id"];
$nameis=$fetchdta["name"];
$emailis=$fetchdta["email"];
$dobis=$fetchdta["date_of_birth"];

 
echo $idis.",".$nameis.",".$emailis.",".$dobis.",";

 
?>