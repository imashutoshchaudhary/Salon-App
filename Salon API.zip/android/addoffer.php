<?php
session_start();
if($_SERVER["REQUEST_METHOD"]=="GET")
{
	include "config.php";
	
        $name=$_GET['name'];
       $amount=$_GET['amount'];
	$coupon=$_GET['coupon_code'];
     $id=$_GET['salon_id'];
        

	
	$query="insert INTO offers(name,amount,coupon_code,salon_id) values('$name','$amount','$coupon','$id')";
	
	if(mysqli_query($conn,$query))
	{
	   echo "data inserted";
	   
	   		 }
			 
			 else
			 {
			   echo "data not inserted";
			 }
			 
		 }
		 
		 
		 
		 
		 
?>