<?php

if($_SERVER["REQUEST_METHOD"]=="GET")
{
	include "config.php";
        $getservicename=$_GET['name'];

	
	$query="insert INTO services(name) values('$getservicename')";
	
	if(mysqli_query($conn,$query))
	{
	   echo "data inserted";
	   
	   		 }
			 
			 else
			 {
			   echo "data not inserted";
			 }
			 
		 }
		 
		 
		 
		 
		 
?>