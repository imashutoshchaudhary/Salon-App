<?php

if($_SERVER['REQUEST_METHOD']=="GET")

{

	$ids=$_GET['salon_id'];
	
	include("config.php");
	
	$queri="delete from offers where salon_id='$ids'";
	
	if(mysqli_query($conn,$queri))
	
{
	echo "data deleted";
}

else

{
	echo "data not deleted";
}

}

?>